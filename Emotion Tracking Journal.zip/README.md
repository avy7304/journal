
  # Emotion Tracking Journal

  This is a code bundle for Emotion Tracking Journal. The original project is available at https://www.figma.com/design/hrpRlbcM3WL34qPTfzzsnc/Emotion-Tracking-Journal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  