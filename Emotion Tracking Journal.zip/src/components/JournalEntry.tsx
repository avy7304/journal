import { Trash2, Calendar } from 'lucide-react';
import { Entry, emotions } from '../App';

interface JournalEntryProps {
  entry: Entry;
  onDelete: (id: string) => void;
}

export function JournalEntry({ entry, onDelete }: JournalEntryProps) {
  const emotion = emotions.find(e => e.value === entry.emotion);
  const date = new Date(entry.date);
  const formattedDate = date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const formattedTime = date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className={`p-6 rounded-lg border-2 ${emotion?.color || 'bg-white border-gray-200'} shadow-sm`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{emotion?.emoji}</span>
          <div>
            <h3 className="text-purple-900">{entry.title}</h3>
            <div className="flex items-center gap-2 text-purple-600 text-sm mt-1">
              <Calendar className="w-4 h-4" />
              <span>{formattedDate} at {formattedTime}</span>
            </div>
          </div>
        </div>
        <button
          onClick={() => onDelete(entry.id)}
          className="text-red-500 hover:text-red-700 transition-colors p-2"
          aria-label="Delete entry"
        >
          <Trash2 className="w-5 h-5" />
        </button>
      </div>

      {/* Content */}
      <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{entry.content}</p>
    </div>
  );
}
