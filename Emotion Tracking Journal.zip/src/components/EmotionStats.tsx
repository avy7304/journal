import { Entry, emotions } from '../App';

interface EmotionStatsProps {
  entries: Entry[];
}

export function EmotionStats({ entries }: EmotionStatsProps) {
  const emotionCounts = entries.reduce((acc, entry) => {
    acc[entry.emotion] = (acc[entry.emotion] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const mostCommon = Object.entries(emotionCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  return (
    <div className="bg-white p-6 rounded-lg border border-purple-200 shadow-sm mb-6">
      <h3 className="mb-4 text-purple-900">Your Emotional Overview</h3>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
        <div className="text-center p-4 bg-purple-50 rounded-lg">
          <div className="text-purple-600">Total Entries</div>
          <div className="text-3xl text-purple-900">{entries.length}</div>
        </div>
        
        <div className="text-center p-4 bg-purple-50 rounded-lg">
          <div className="text-purple-600">Days Journaling</div>
          <div className="text-3xl text-purple-900">
            {new Set(entries.map(e => new Date(e.date).toDateString())).size}
          </div>
        </div>
        
        <div className="text-center p-4 bg-purple-50 rounded-lg">
          <div className="text-purple-600">Most Common</div>
          <div className="text-3xl">
            {emotions.find(e => e.value === mostCommon[0]?.[0])?.emoji || '📝'}
          </div>
        </div>
      </div>

      {/* Top Emotions */}
      {mostCommon.length > 0 && (
        <div>
          <h4 className="text-sm text-purple-700 mb-2">Top Emotions:</h4>
          <div className="flex flex-wrap gap-2">
            {mostCommon.map(([emotionValue, count]) => {
              const emotion = emotions.find(e => e.value === emotionValue);
              return (
                <div
                  key={emotionValue}
                  className={`flex items-center gap-2 px-3 py-2 rounded-full border ${emotion?.color}`}
                >
                  <span className="text-xl">{emotion?.emoji}</span>
                  <span className="text-sm">{emotion?.label}</span>
                  <span className="text-sm bg-white px-2 py-0.5 rounded-full">{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
