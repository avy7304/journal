import { useState } from 'react';
import { emotions, Entry } from '../App';

interface EntryFormProps {
  onSubmit: (entry: Omit<Entry, 'id'>) => void;
}

export function EntryForm({ onSubmit }: EntryFormProps) {
  const [emotion, setEmotion] = useState('');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emotion || !title || !content) return;

    onSubmit({
      date: new Date().toISOString(),
      emotion,
      title,
      content,
    });

    // Reset form
    setEmotion('');
    setTitle('');
    setContent('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg border border-purple-200 shadow-sm">
      <h3 className="mb-4 text-purple-900">How are you feeling?</h3>

      {/* Emotion Selection */}
      <div className="mb-4">
        <label className="block mb-2 text-purple-900">Select your emotion:</label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {emotions.map(emo => (
            <button
              key={emo.value}
              type="button"
              onClick={() => setEmotion(emo.value)}
              className={`p-3 rounded-lg border-2 transition-all ${
                emotion === emo.value
                  ? `${emo.color} border-2`
                  : 'bg-white border-gray-200 hover:border-purple-300'
              }`}
            >
              <div className="text-2xl mb-1">{emo.emoji}</div>
              <div className="text-sm">{emo.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Title */}
      <div className="mb-4">
        <label className="block mb-2 text-purple-900">Entry Title:</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Give your entry a title..."
          className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
          required
        />
      </div>

      {/* Content */}
      <div className="mb-4">
        <label className="block mb-2 text-purple-900">Your thoughts:</label>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Write about your day, feelings, or anything on your mind..."
          rows={6}
          className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
          required
        />
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        disabled={!emotion || !title || !content}
        className="w-full bg-purple-600 text-white py-2 px-6 rounded-lg hover:bg-purple-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
      >
        Save Entry
      </button>
    </form>
  );
}
