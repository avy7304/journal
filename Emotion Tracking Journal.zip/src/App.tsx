import { useState, useEffect } from 'react';
import { JournalEntry } from './components/JournalEntry';
import { EntryForm } from './components/EntryForm';
import { EmotionStats } from './components/EmotionStats';
import { BookHeart } from 'lucide-react';
import { projectId, publicAnonKey } from './utils/supabase/info';

export interface Entry {
  id: string;
  date: string;
  emotion: string;
  title: string;
  content: string;
}

export const emotions = [
  { value: 'happy', label: 'Happy', emoji: '😊', color: 'bg-yellow-100 border-yellow-300' },
  { value: 'sad', label: 'Sad', emoji: '😢', color: 'bg-blue-100 border-blue-300' },
  { value: 'anxious', label: 'Anxious', emoji: '😰', color: 'bg-purple-100 border-purple-300' },
  { value: 'excited', label: 'Excited', emoji: '🤩', color: 'bg-orange-100 border-orange-300' },
  { value: 'calm', label: 'Calm', emoji: '😌', color: 'bg-green-100 border-green-300' },
  { value: 'angry', label: 'Angry', emoji: '😠', color: 'bg-red-100 border-red-300' },
  { value: 'grateful', label: 'Grateful', emoji: '🙏', color: 'bg-pink-100 border-pink-300' },
  { value: 'tired', label: 'Tired', emoji: '😴', color: 'bg-gray-100 border-gray-300' },
];

const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-08999103`;

export default function App() {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [filterEmotion, setFilterEmotion] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchEntries();
  }, []);

  const fetchEntries = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch(`${API_URL}/entries`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch entries');
      }
      
      const data = await response.json();
      console.log('Fetched entries:', data);
      const sortedEntries = (data.entries || []).sort((a: Entry, b: Entry) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      setEntries(sortedEntries);
    } catch (err) {
      console.error('Error fetching entries:', err);
      setError('Failed to load entries. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddEntry = async (entry: Omit<Entry, 'id'>) => {
    try {
      const response = await fetch(`${API_URL}/entries`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(entry),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create entry');
      }
      
      const data = await response.json();
      console.log('Created entry:', data);
      setEntries([data.entry, ...entries]);
      setShowForm(false);
    } catch (err) {
      console.error('Error creating entry:', err);
      setError('Failed to create entry. Please try again.');
    }
  };

  const handleDeleteEntry = async (id: string) => {
    try {
      const response = await fetch(`${API_URL}/entries/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete entry');
      }
      
      setEntries(entries.filter(entry => entry.id !== id));
    } catch (err) {
      console.error('Error deleting entry:', err);
      setError('Failed to delete entry. Please try again.');
    }
  };

  const filteredEntries = filterEmotion === 'all' 
    ? entries 
    : entries.filter(entry => entry.emotion === filterEmotion);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-4">📔</div>
          <p className="text-purple-600">Loading your journal...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-2">
            <BookHeart className="w-10 h-10 text-purple-600" />
            <h1 className="text-purple-900">Emotion Journal</h1>
          </div>
          <p className="text-purple-700">Track your feelings and thoughts</p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-600">{error}</p>
          </div>
        )}

        {/* Stats */}
        {entries.length > 0 && (
          <EmotionStats entries={entries} />
        )}

        {/* New Entry Button */}
        <div className="mb-6">
          <button
            onClick={() => setShowForm(!showForm)}
            className="w-full bg-purple-600 text-white py-3 px-6 rounded-lg hover:bg-purple-700 transition-colors"
          >
            {showForm ? 'Cancel' : '+ New Journal Entry'}
          </button>
        </div>

        {/* Entry Form */}
        {showForm && (
          <div className="mb-6">
            <EntryForm onSubmit={handleAddEntry} />
          </div>
        )}

        {/* Filter */}
        {entries.length > 0 && (
          <div className="mb-6">
            <label className="block mb-2 text-purple-900">Filter by emotion:</label>
            <select
              value={filterEmotion}
              onChange={(e) => setFilterEmotion(e.target.value)}
              className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            >
              <option value="all">All Emotions</option>
              {emotions.map(emotion => (
                <option key={emotion.value} value={emotion.value}>
                  {emotion.emoji} {emotion.label}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Entries List */}
        <div className="space-y-4">
          {filteredEntries.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg border border-purple-100">
              <p className="text-purple-600">
                {entries.length === 0 
                  ? 'No journal entries yet. Start by creating your first entry!'
                  : 'No entries found with the selected emotion filter.'}
              </p>
            </div>
          ) : (
            filteredEntries.map(entry => (
              <JournalEntry
                key={entry.id}
                entry={entry}
                onDelete={handleDeleteEntry}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}