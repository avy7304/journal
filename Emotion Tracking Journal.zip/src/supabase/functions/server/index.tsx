import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-08999103/health", (c) => {
  return c.json({ status: "ok" });
});

// Get all journal entries
app.get("/make-server-08999103/entries", async (c) => {
  try {
    const entries = await kv.getByPrefix("entry:");
    return c.json({ entries: entries || [] });
  } catch (error) {
    console.error("Error fetching entries:", error);
    return c.json({ error: "Failed to fetch entries", details: error.message }, 500);
  }
});

// Create a new journal entry
app.post("/make-server-08999103/entries", async (c) => {
  try {
    const entry = await c.req.json();
    const id = Date.now().toString();
    const newEntry = { ...entry, id };
    await kv.set(`entry:${id}`, newEntry);
    return c.json({ entry: newEntry });
  } catch (error) {
    console.error("Error creating entry:", error);
    return c.json({ error: "Failed to create entry", details: error.message }, 500);
  }
});

// Delete a journal entry
app.delete("/make-server-08999103/entries/:id", async (c) => {
  try {
    const id = c.req.param("id");
    await kv.del(`entry:${id}`);
    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting entry:", error);
    return c.json({ error: "Failed to delete entry", details: error.message }, 500);
  }
});

Deno.serve(app.fetch);